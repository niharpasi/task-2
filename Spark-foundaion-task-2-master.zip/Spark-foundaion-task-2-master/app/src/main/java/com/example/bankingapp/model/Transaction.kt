package com.example.bankingapp.model

data class Transaction(var date: String,var FromName:String,var toName:String,var amount:String,var status:String)