package com.example.bankingapp.dbHelper
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import android.widget.Toast
import com.example.bankingapp.model.Customer
import com.example.bankingapp.model.Transaction


class DBhelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null , DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE $TABLE_NAME ($PHONENUMBER_COl INTEGER PRIMARY KEY, $NAME_COl TEXT,$BALANCE_COL DECIMAL,$EMAIL_COL VARCHAR,$ACCOUNT_NO_COL VARCHAR,$IFSC_CODE_COL VARCHAR)")
        db.execSQL("CREATE TABLE $TABLE_NAME1 ($TRANSACTIONID INTEGER PRIMARY KEY AUTOINCREMENT, $DATE TEXT,$FROMNAME TEXT,$TONAME TEXT,$AMOUNT DECIMAL,$STATUS TEXT)")
        db.execSQL("insert into $TABLE_NAME values(8850748542,'Nihar Pasi',10000.00,'niharpasi123@gmail.com','XXXXXXXXXXXX1234','NBG64853542')")
        db.execSQL("insert into $TABLE_NAME values(7999927343,'Yash Patil',9982.32,'patil102@gmail.com','XXXXXXXXXXXX2376','BCA98765438')")
        db.execSQL("insert into $TABLE_NAME values(7382943843,'Sahil Gaikwad',1359.56,'sg44@gmail.com','XXXXXXXXXXXX2247','CAB87654325')")
        db.execSQL("insert into $TABLE_NAME values(4627284936,'Pratham Goverkar',1500.01,'pratham32@gmail.com','XXXXXXXXXXXX4245','ABC76543213')")
        db.execSQL("insert into $TABLE_NAME values(6272819734,'Ramsha Beg',699.22,'rbeg00@gmail.com','XXXXXXXXXXXX7654','BCA65432108')")
        db.execSQL("insert into $TABLE_NAME values(0000062728,'Sahana Kumbar',945.16,'ksahana@gmail.com','XXXXXXXXXXXX2345','CAB54321099')")
        db.execSQL("insert into $TABLE_NAME values(5362791622,'Bhakti Bhoir',5936.00,'bhakti@gmail.com','XXXXXXXXXXXX0022','ABC43210984')")
        db.execSQL("insert into $TABLE_NAME values(7118328709,'Siddhi K',857.22,'ks22@gmail.com','XXXXXXXXXXXX6655','BCA32109879')")
        db.execSQL("insert into $TABLE_NAME values(9374827390,'Ashwini Singh',4398.46,'ash22@gmail.com','XXXXXXXXXXXX0865','CAB21098766')")
        db.execSQL("insert into $TABLE_NAME values(1234567809,'Priyanka Dalal',7739.20,'priyanka@gmail.com','XXXXXXXXXXXX0274','ABC10987650')")
        db.execSQL("insert into $TABLE_NAME1 values(2324,'20/03/22','Nihar Pasi','Sahil',1000.00,'Success')")
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }
    fun insertTransferData(
        date: String?,
        from_name: String?,
        to_name: String?,
        amount: String?,
        status: String?
    ){
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(DATE, date)
        values.put(FROMNAME, from_name)
        values.put(TONAME, to_name)
        values.put(AMOUNT, amount)
        values.put(STATUS, status)
        db.insert(TABLE_NAME1, null, values)
        db.close()
    }
    fun updateAmount(phoneNumber: String, amount: String) {
        val db = this.writableDatabase
        db.execSQL("update Customers set $BALANCE_COL = $amount where $PHONENUMBER_COl = $phoneNumber")
    }
    fun getCustomers(context: Context): ArrayList<Customer> {
        val qry = "SELECT * From $TABLE_NAME"
        val db = this.readableDatabase
        val cursor:Cursor = db.rawQuery(qry,null)
        val customers = ArrayList<Customer>()
        while(cursor.moveToNext()){
            val customer = Customer(cursor.getString(cursor.getColumnIndexOrThrow(NAME_COl)),
                cursor.getLong(cursor.getColumnIndexOrThrow(PHONENUMBER_COl)),
                cursor.getDouble(cursor.getColumnIndexOrThrow(BALANCE_COL)),
                cursor.getString(cursor.getColumnIndexOrThrow(EMAIL_COL)),
                cursor.getString(cursor.getColumnIndexOrThrow(ACCOUNT_NO_COL)),
                cursor.getString(cursor.getColumnIndexOrThrow(IFSC_CODE_COL)))
            customers.add(customer)
        }
        cursor.close()
        db.close()
        return customers
    }
    fun getTransaction(context: Context): ArrayList<Transaction> {
        val qry = "SELECT * From $TABLE_NAME1"
        val db = this.readableDatabase
        val cursor:Cursor = db.rawQuery(qry,null)
        val transactions = ArrayList<Transaction>()
        while(cursor.moveToNext()){
            val transaction = Transaction(cursor.getString(cursor.getColumnIndexOrThrow(DATE)),
                cursor.getString(cursor.getColumnIndexOrThrow(FROMNAME)),
                cursor.getString(cursor.getColumnIndexOrThrow(TONAME)),
                cursor.getString(cursor.getColumnIndexOrThrow(AMOUNT)),
                cursor.getString(cursor.getColumnIndexOrThrow(STATUS)))
            transactions.add(transaction)
        }
        cursor.close()
        db.close()
        return transactions
    }
    fun readParticularData(phoneNumber: String): Cursor? {
        val qry = "SELECT $BALANCE_COL from $TABLE_NAME where $PHONENUMBER_COl = $phoneNumber"
        val db = this.readableDatabase
        return db.rawQuery(qry, null)
    }

    fun readselectuserdata(phoneNumber: String): Cursor? {
        val db = this.readableDatabase
        return db.rawQuery(
            "select * from user_table except select * from user_table where phoneNumber = $phoneNumber",
            null
        )
    }
    companion object{
        private const val DATABASE_NAME = "SparkBank"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "Customers"
        private const val TABLE_NAME1 = "Transactions"
        val PHONENUMBER_COl = "id"
        val NAME_COl = "name"
        val BALANCE_COL = "balance"
        val EMAIL_COL = "email"
        val ACCOUNT_NO_COL = "accountNo"
        val IFSC_CODE_COL = "ABC09876541"
        val STATUS = "status"
        val AMOUNT = "amount"
        val TONAME = "toName"
        val FROMNAME = "fromName"
        val DATE = "date"
        val TRANSACTIONID = "transID"
    }
}